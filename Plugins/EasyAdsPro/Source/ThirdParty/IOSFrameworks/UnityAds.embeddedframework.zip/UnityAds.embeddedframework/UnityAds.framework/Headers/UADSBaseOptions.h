#import <UnityAds/UADSDictionaryConvertible.h>

@interface UADSBaseOptions : NSObject<UADSDictionaryConvertible>

@property (nonatomic, retain, strong, readonly) NSDictionary *dictionary;
@property (nonatomic, retain, readwrite) NSString *objectId;

- (instancetype)init;

@end
